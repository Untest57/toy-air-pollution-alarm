import N1 from './1.json';
import N2 from './2.json';

export default [N1, N2];
